﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StorageMaster.Core
{
    public class Engine
    {
        private StorageMaster storageMaster;

        private bool IsRunning;

        public Engine(StorageMaster storageMaster)
        {
            this.storageMaster = new StorageMaster();
            this.IsRunning = false;
        }
        public void Run()
        {
            IsRunning = true;

            while(IsRunning)
            {
                string line = Console.ReadLine();

                string[] tokens = line.Split();
                string command = tokens[0];

                string output = "";
                try
                {
                    switch (command)
                    {
                        case "AddProduct":
                            string productType = tokens[1];
                            double productPrice = double.Parse(tokens[2]);
                            output = this.storageMaster.AddProduct(productType, productPrice);
                            break;
                        case "RegisterStorage":
                            string storageType = tokens[1];
                            string stoName = tokens[2];
                            output = this.storageMaster.RegisterStorage(storageType, stoName);
                            break;
                        case "SelectVehicle":
                            string storageName = tokens[1];
                            int garageSlot = int.Parse(tokens[2]);
                            output = this.storageMaster.SelectVehicle(storageName, garageSlot);
                            break;
                        case "LoadVehicle":
                            output = this.storageMaster.LoadVehicle(tokens.Skip(1));
                            break;
                        case "SendVehicleTo":
                            string sourceName = tokens[1];
                            int sourceGarageSlot = int.Parse(tokens[2]);
                            string destinationName = tokens[3];
                            output = this.storageMaster.SendVehicleTo(sourceName, sourceGarageSlot, destinationName);
                            break;
                        case "UnloadVehicle":
                            string strName = tokens[1];
                            int garSlot = int.Parse(tokens[2]);
                            output = this.storageMaster.UnloadVehicle(strName, garSlot);
                            break;
                        case "GetStorageStatus":
                            string storName = tokens[1];
                            output = this.storageMaster.GetStorageStatus(storName);
                            break;
                        case "END":

                            output = this.storageMaster.GetSummary();
                            this.IsRunning = false;
                            break;
                    }
                }
                catch (InvalidOperationException ex)
                {

                    output = $"Error: {ex.Message}";
                }
                Console.WriteLine(output);
            }
        }
    }
}
