﻿using System;
using System.Collections.Generic;
using System.Text;
using StorageMaster.Entities.Vehicles;

namespace StorageMaster.Entities.Storages
{
    public class Warehouse : Storage
    {
        private const int WarehouseCapacity = 10;
        private const int WarehouseGarageSlots = 10;

        private static readonly Vehicle[] DefaultVehicles = new Vehicle[]
        {
            new Semi(),
            new Semi(),
            new Semi()
        };
        public Warehouse(string name) 
            : base(name, WarehouseCapacity, WarehouseGarageSlots, DefaultVehicles)
        {
        }
    }
}
