﻿using StorageMaster.Entities.Storages;
using System;
using System.Collections.Generic;
using System.Text;

namespace StorageMaster.Factories
{
    public class StorageFactory
    {
        public Storage CreateStorage(string type, string name)
        {
            Storage storage = null;
            switch (type)
            {
                case "Warehouse":
                    storage = new Warehouse(name);
                    break;
                case "DistributionCenter":
                    storage = new DistributionCenter(name);
                    break;
                case "AutomatedWarehouse":
                    storage = new AutomatedWarehouse(name);
                    break;
                default:
                    throw new InvalidOperationException("Invalid storage type!");
                    
            }
            return storage;
        }
    }
}
